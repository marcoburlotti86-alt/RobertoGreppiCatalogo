-- Roberto Greppi Milano B2B catalog schema (Supabase / PostgreSQL)
-- Review and apply in Supabase SQL Editor only after creating the project.
create extension if not exists pgcrypto;
create type public.account_role as enum ('admin','customer');
create type public.order_status as enum ('received','confirmed','processing','shipped','completed','cancelled');
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.account_role not null default 'customer',
  company_name text not null,
  contact_name text,
  email text,
  phone text,
  active boolean not null default false,
  created_at timestamptz not null default now()
);
create table public.products (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  description text not null default '',
  material text not null check (material in ('Argento','Ottone','Altro')),
  category text not null,
  image_1 text,
  image_2 text,
  stock_band text not null default 'da_verificare' check (stock_band in ('disponibile','limitata','esaurita','da_verificare')),
  active boolean not null default true,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.customer_prices (
  customer_id uuid not null references public.profiles(id) on delete cascade,
  product_id uuid not null references public.products(id) on delete cascade,
  price numeric(10,2) not null check (price >= 0),
  currency char(3) not null default 'EUR',
  updated_at timestamptz not null default now(),
  primary key (customer_id, product_id)
);
create table public.orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references public.profiles(id),
  status public.order_status not null default 'received',
  customer_note text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  product_code_snapshot text not null,
  product_name_snapshot text not null,
  quantity integer not null check (quantity > 0),
  unit_price_snapshot numeric(10,2) check (unit_price_snapshot >= 0)
);
create index products_active_category_idx on public.products(active, category);
create index orders_customer_created_idx on public.orders(customer_id, created_at desc);
create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.profiles p where p.id=auth.uid() and p.role='admin' and p.active=true); $$;
alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.customer_prices enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
create policy "profile self or admin read" on public.profiles for select using (id=auth.uid() or public.is_admin());
create policy "admin manages profiles" on public.profiles for all using (public.is_admin()) with check (public.is_admin());
create policy "active products visible to active accounts" on public.products for select using (active=true and exists(select 1 from public.profiles p where p.id=auth.uid() and p.active=true) or public.is_admin());
create policy "admin manages products" on public.products for all using (public.is_admin()) with check (public.is_admin());
create policy "customer sees own prices" on public.customer_prices for select using (customer_id=auth.uid() or public.is_admin());
create policy "admin manages prices" on public.customer_prices for all using (public.is_admin()) with check (public.is_admin());
create policy "customer sees own orders" on public.orders for select using (customer_id=auth.uid() or public.is_admin());
create policy "active customer creates own order" on public.orders for insert with check (customer_id=auth.uid() and exists(select 1 from public.profiles p where p.id=auth.uid() and p.active=true));
create policy "admin updates orders" on public.orders for update using (public.is_admin()) with check (public.is_admin());
create policy "customer sees own order items" on public.order_items for select using (exists(select 1 from public.orders o where o.id=order_id and (o.customer_id=auth.uid() or public.is_admin())));
create policy "active customer inserts own order items" on public.order_items for insert with check (exists(select 1 from public.orders o join public.profiles p on p.id=o.customer_id where o.id=order_id and o.customer_id=auth.uid() and p.active=true));
create policy "admin manages order items" on public.order_items for all using (public.is_admin()) with check (public.is_admin());
-- IMPORTANT: set the first admin explicitly after creating their Auth user; do not expose the service-role key in frontend code.
